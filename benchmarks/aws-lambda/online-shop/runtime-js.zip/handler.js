
const currency = require('./currency.js');
const payment = require('./payment.js');

const LAMBDA = true;
if (LAMBDA) {
    exports.handler = async (event) => {
        if (event.type === 'currency') {
            result = currency.currencyFunction(input["body"]);
            return result
        } else {
            result = payment.paymentFunction(input["body"]);
            return result
        }
    };
}
else {
    function main(body) {
        const input = JSON.parse(body);
        if (input["type"] == "currency") {
            //console.log(input["body"])
            result = currency.currencyFunction(input["body"]);
            console.log("Result")
            console.log(result)
            return result
        }
        else if (input["type"] == "payment") {
            //console.log(input["body"])
            result = payment.paymentFunction(input["body"]);
            console.log("Result")
            console.log(result)
            return result
        }
    }

    if (require.main == module) {
        main(process.argv[2])
    }

}



